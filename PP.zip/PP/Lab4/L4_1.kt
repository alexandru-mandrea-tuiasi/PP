data class Content(val author: String, val text: String, val name: String, var publisher: String)

class Book(private val content: Content) 
{
    override fun toString(): String 
    {
        return "Book(name='${content.name}', author='${content.author}', publisher='${content.publisher}')"
    }

    fun getName(): String 
    {
        return content.name
    }

    fun getAuthor(): String 
    {
        return content.author
    }

    fun getPublisher(): String 
    {
        return content.publisher
    }

    fun getContent(): Content 
    {
        return content
    }

    fun hasAuthor(author: String): Boolean 
    {
        return content.author == author
    }

    fun hasTitle(title: String): Boolean 
    {
        return content.name == title
    }

    fun isPublishedBy(publisher: String): Boolean 
    {
        return content.publisher == publisher
    }
}

class Library {
    private val books: MutableSet<Book> = mutableSetOf()

    fun getBooks(): Set<Book> 
    {
        return books.toSet()
    }

    fun addBook(book: Book) {
        books.add(book)
    }

    fun findAllByAuthor(author: String): Set<Book> 
    {
        return books.filter { it.getAuthor() == author }.toSet()
    }

    fun findAllByName(name: String): Set<Book> 
    {
        return books.filter { it.getName() == name }.toSet()
    }

    fun findAllByPublisher(publisher: String): Set<Book> 
    {
        return books.filter { it.getPublisher() == publisher }.toSet()
    }
}

class LibraryPrinter 
{
    fun printBooksRaw(books: Set<Book>) 
    {
        println("Printing books in raw format:")
        books.forEach { println(it) }
    }

    fun printHTML(books: Set<Book>) 
    {
        println("Printing books in HTML format:")
        println("<ul>")
        books.forEach { println("<li>${it.getName()} by ${it.getAuthor()} - Publisher: ${it.getPublisher()}</li>") }
        println("</ul>")
    }

    fun printJSON(books: Set<Book>) 
    {
        println("Printing books in JSON format:")
        val jsonBooks = books.map {
            """{"name": "${it.getName()}", "author": "${it.getAuthor()}", "publisher": "${it.getPublisher()}"}"""
        }
        
        println("[${jsonBooks.joinToString(", ")}]")
    }
}

fun main() {
    val content1 = Content("Ion", "ttttttttt", "O scrisoare pierduta", "Convorbiri literare")
    val book1 = Book(content1)

    val content2 = Content("Liviu", "llllllll", "Ion", "Convorbiri literare")
    val book2 = Book(content2)

    val content3 = Content("Mihail", "hhhhhhhhh", "Baltagul", "Convorbiri literare")
    val book3 = Book(content3)

    val books: Set<Book> = setOf(book1, book2, book3)

    val printer = LibraryPrinter()
    printer.printBooksRaw(books)
    println()
    printer.printHTML(books)
    println()
    printer.printJSON(books)
}
