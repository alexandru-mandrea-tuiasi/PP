#include "stack.h"

void stack_char_push(stack_char_t *stack, char character)
{
    stack->data[stack->length] = character;
    stack->length++;
}

char stack_char_pop(stack_char_t *stack)
{
    char result = 0;

    stack->length--;
    result = stack->data[stack->length];
    stack->data[stack->length] = 0;

    return result;
}

char stack_char_top(stack_char_t stack)
{
    char result = 0;

    stack.length--;
    result = stack.data[stack.length];

    return result;
}

bool stack_char_isEmpty(stack_char_t stack)
{
    return stack.length == 0;
}

void stack_char_init(stack_char_t *stack, size_t stack_size)
{
    for(size_t i = 0; i < stack_size; i++)
    {
        stack->data[i] = 0;
    }
}

void stack_double_push(stack_double_t *stack, double elem)
{
    stack->data[stack->length] = elem;
    stack->length++;
}

double stack_double_pop(stack_double_t *stack)
{
    double result = 0;

    stack->length--;
    result = stack->data[stack->length];
    stack->data[stack->length] = 0;

    return result;
}

double stack_double_top(stack_double_t stack)
{
    double result = 0;

    stack.length--;
    result = stack.data[stack.length];

    return result;
}

bool stack_double_isEmpty(stack_double_t stack)
{
    return stack.length == 0;
}

void stack_double_init(stack_double_t *stack, size_t stack_size)
{
    for(size_t i = 0; i < stack_size; i++)
    {
        stack->data[i] = 0;
    }
}