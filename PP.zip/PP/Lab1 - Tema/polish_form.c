#include "polish_form.h"
#include "stack.h"

bool isOperator(char character)
{
    return (character == '+') || (character == '-') || (character == '*') || (character == '/');
}

bool isOperand(char character)
{
    return isalnum(character);
}

bool isOpenBracket(char character)
{
    return character == '(';
}

bool isClosedBracket(char character)
{
    return character == ')';
}

int precedence(char operator)
{
    //TODO: add support for trg functions
    char precedence_table[] = "+-*/";
    
    for(int i = 0; (size_t)i < strlen(precedence_table); i++)
    {
        if(operator == precedence_table[i])
        {
            return i+1;
        }

    }

    return -1;
}

void polishForm(char *expression)
{
    char symbol = 0, next_symbol = 0;

    char *expression_infix = malloc(sizeof(char) * strlen(expression));
    if(expression_infix == NULL)
    {
        fprintf(stderr, "polishForm(%p): Error: couldn't allocate memory for expression_infix %p", expression, expression_infix);
        exit(-1);
    }
    strcpy(expression_infix, expression);

    stack_char_t stack = {
        .length = 0,
        .data = malloc(sizeof(char) * strlen(expression))
    };
    if(stack.data == NULL)
    {
        fprintf(stderr, "polishForm(%p): Error: couldn't allocate memory for stack.data %p", expression, stack.data);
        exit(-1);
    }

    size_t i = 0, j = 0;

    for(i = 0, j = 0; i < strlen(expression_infix); i++)
    {
        symbol = expression_infix[i];
        
        if(isOpenBracket(symbol))
        {
            stack_char_push(&stack, symbol);
        }

        else if(isClosedBracket(symbol))
        {
            while((next_symbol = stack_char_pop(&stack)) != '(')
            {
                expression[j++] = next_symbol;
            }
        }

        else if(isOperator(symbol))
        {
            while(!stack_char_isEmpty(stack) && (precedence(stack_char_top(stack)) >= precedence(symbol)))
            {
                expression[j++] = stack_char_pop(&stack);
            }

            stack_char_push(&stack, symbol);
        }

        else if (isOperand(symbol))
        {
            expression[j++] = symbol;
        }

    }

    while(!stack_char_isEmpty(stack))
    {
        expression[j++] = stack_char_pop(&stack);
    }
    expression[j] = '\0';

    free(stack.data);
    stack.data = NULL;

    free(expression_infix);
    expression_infix = NULL;
}

void checkExpression(char *expression, char* operands)
{
    if(expression == NULL)
    {
        fprintf(stderr, "checkExpression(char* expression %s, char* operands %s): Error: expression is null!\n", expression, operands);
        exit(-1);
    }

    if(operands == NULL)
    {
        fprintf(stderr, "parseInput(char* operands %s): Error: operands %s is null!\n", expression, operands);
        exit(-1);
    }

   if(strlen(expression) < 3)
    {
        fprintf(stderr, "checkExpression(char* expression %s): Error: expression is invalid!\n", expression);
        exit(-1);
    }

    size_t tokens = 0, operators = 0;

    for(size_t i = 0; expression[i]; i++)
    {
        if(isOperand(expression[i]))
        {
            tokens++;
        }
        
        else if(isOperator(expression[i]))
        {
            operators++;
        }

    }

    if(tokens != (operators + 1))
    {
        fprintf(stderr, "evaluateExpression(char* expression %p): Error: expression is invalid!\n", expression);
        exit(-1);
    }

}

double evaluateExpression(char *expression, char* operands)
{
    checkExpression(expression, operands);
    
    const char *delimiters = "+-*/()";

    stack_double_t stack = {
        .length = 0,
        .data = malloc(sizeof(double) * (strlen(expression) / 2 + 1))
    };
    stack_double_init(&stack, strlen(expression) / 2 + 1);

    double result = 0;
    double operand1 = 0, operand2 = 0;
    size_t expression_index = 0;

    for(expression_index = 0; expression[expression_index] != '\0'; expression_index++)
    {
        char symbol = expression[expression_index];

        switch (symbol)
        {
            case '+':
                operand2 = stack_double_pop(&stack);
                operand1 = stack_double_pop(&stack);

                result = operand1 + operand2;
                stack_double_push(&stack, result);

            break;

            case '-':
                operand2 = stack_double_pop(&stack);
                operand1 = stack_double_pop(&stack);

                result = operand1 - operand2;
                stack_double_push(&stack, result);
            break;

            case '*':
                operand2 = stack_double_pop(&stack);
                operand1 = stack_double_pop(&stack);

                result = operand1 * operand2;
                stack_double_push(&stack, result);
            break;

            case '/':
                operand2 = stack_double_pop(&stack);
                operand1 = stack_double_pop(&stack);

                result = operand1 / operand2;
                stack_double_push(&stack, result);
            break;
        
            default:
                if(operands != NULL)
                {
                    stack_double_push(&stack, atof(operands));
                    operands = strtok(NULL, delimiters);
                }
                
        }

    }

    return result;
}
