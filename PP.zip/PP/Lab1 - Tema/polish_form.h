#ifndef POLISH_FORM_H_
#define POLISH_FORM_H_

#include <stdint.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define CHUNK_SIZE 64

void polishForm(char *expression);
double evaluateExpression(char *expression, char* operands);
bool isOperator(char character);
bool isOperand(char character);

#endif