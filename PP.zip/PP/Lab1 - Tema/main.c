#include "polish_form.h"

void printExpression(char* expression)
{
    if(expression == NULL)
    {
        fprintf(stderr, "printExpression(char* expression %p): Error: expression is null!\n", expression);
        exit(-1);
    }

    printf("Expression: ");
    for(size_t i = 0; expression[i] != '\0'; i++)
    {
        printf("%c", expression[i]);
    }
    printf("\n");
}

void removeSpaces(char* expression)
{
    if(expression == NULL)
    {
        fprintf(stderr, "removeSpaces(char* expression %p): Error: expression is null!\n", expression);
        exit(-1);
    }

    size_t writer = 0, reader = 0;

    while (expression[reader])
    {
        if ((expression[reader] != ' ') && (expression[reader] != '\t')) 
        {   
            expression[writer++] = expression[reader];
        }

        reader++;       
    }

    expression[writer]=0;
}

bool deleteChar(char* expression, size_t expression_index)
{
    if(expression == NULL)
    {
        fprintf(stderr, "deleteChar(char* expression %p, size_t expression_index %lu): Error: expression is null!\n", expression, expression_index);
        exit(-1);
    }

    memmove(&expression[expression_index], &expression[expression_index + sizeof(char)], strlen(expression) - expression_index);
    expression = realloc(expression, strlen(expression));

    if(expression == NULL)
    {
        fprintf(stderr, "deleteChar(char* expression %p, size_t expression_index %lu): Error: couldn't resize array!\n", expression, expression_index);
        return false;
    }

    return true;
}

char* getOperands(char* expression)
{
    if(expression == NULL)
    {
        fprintf(stderr, "getOperands(char* expression %p): Error: expression is null!\n", expression);
        exit(-1);
    }

    const char *delimiters = "+-*/()";
    char *operands = NULL;

    if((operands = malloc(strlen(expression))) != NULL)
    {
        memcpy(operands, expression, strlen(expression));
        strtok(operands, delimiters);
    }
    
    return operands;
}

void tokenize(char* expression)
{
    if(expression == NULL)
    {
        fprintf(stderr, "tokenize(char* expression %p): Error: expression is null!\n", expression);
        exit(-1);
    }

    size_t expression_index = 0;
    size_t tokens = 0;

    for(expression_index = 0; expression[expression_index] != '\0'; expression_index++)
    {
        while(isOperand(expression[expression_index]) == true)
        {
            if(isOperator(expression[expression_index+1]) || !expression[expression_index+1] || expression[expression_index+1] == ')')
            {
                expression[expression_index] = 'T';
                tokens++;
                expression_index++;
            }
            else
            {
                deleteChar(expression, expression_index);
            }
            
        }
        
    }

}

double parseInput(char* expression)
{
    double result = 0;
    
    removeSpaces(expression);
    char* operands = getOperands(expression);
    tokenize(expression);
    polishForm(expression);
    result = evaluateExpression(expression, operands);

    return result;
}

char* readInput(char *input_buffer)
{
    char static_buffer[CHUNK_SIZE];
    char character = 0;

    size_t static_buffer_index = 0;
    static size_t chunks = 1;
    
    do
    {
        character = (char)getchar();
        static_buffer[static_buffer_index] = character;

        if(static_buffer_index == CHUNK_SIZE)
        {
            chunks++;
            input_buffer = realloc(input_buffer, sizeof(char) * CHUNK_SIZE * chunks);
            if(input_buffer == NULL)
            {
                fprintf(stderr, "readInput(char* input_buffer %p): Error: couldn't allocate memory for input_buffer!\n", input_buffer);
                exit(-1);
            }

            memcpy(input_buffer + sizeof(char) * CHUNK_SIZE * (chunks - 1), static_buffer, CHUNK_SIZE);
            static_buffer_index = 0;
        }

        if(character == '\n')
        {
            input_buffer = realloc(input_buffer, sizeof(char) * CHUNK_SIZE * chunks);
            if(input_buffer == NULL)
            {
                fprintf(stderr, "readInput(char* input_buffer %p): Error: couldn't allocate memory for input_buffer!\n", input_buffer);
                exit(-1);
            }

            static_buffer[static_buffer_index] = '\0';
            memcpy(input_buffer + sizeof(char) * CHUNK_SIZE * (chunks - 1), static_buffer, CHUNK_SIZE);
            static_buffer_index = 0;
        }

        static_buffer_index++;
    }while(character != '\n');

    return input_buffer;
}

int main(void)
{
    char *input_buffer = NULL;

    printf("Expression: ");
    input_buffer = readInput(input_buffer);

    printf("Result: %lf\n", parseInput(input_buffer));

    free(input_buffer);
    input_buffer = NULL;

    return 0;
}