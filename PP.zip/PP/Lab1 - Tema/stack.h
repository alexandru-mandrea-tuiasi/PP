#ifndef STACK_H_
#define STACK_H_

#include <stdio.h>
#include <stdbool.h>

typedef struct stack_char_t
{
    int length;
    char *data;
}stack_char_t;

typedef struct stack_double_t
{
    int length;
    double *data;
}stack_double_t;

void stack_char_push(stack_char_t *stack, char character);

char stack_char_pop(stack_char_t *stack);

char stack_char_top(stack_char_t stack);

bool stack_char_isEmpty(stack_char_t stack);

void stack_char_init(stack_char_t *stack, size_t stack_size);

void stack_double_push(stack_double_t *stack, double elem);

double stack_double_pop(stack_double_t *stack);

double stack_double_top(stack_double_t stack);

bool stack_double_isEmpty(stack_double_t stack);

void stack_double_init(stack_double_t *stack, size_t stack_size);



#endif